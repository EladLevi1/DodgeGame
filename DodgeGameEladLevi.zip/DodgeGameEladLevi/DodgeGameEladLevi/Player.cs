﻿using System;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace DodgeGameEladLevi
{
    class Player : Piece
    {
        public Player()
        {
            img();
        }
        public override void img()
        {
            pieceImg = new Image();
            string picname = "player.gif";
            BitmapImage bi = new BitmapImage();
            bi.UriSource = new Uri("ms-appx:///Assets/" + picname, UriKind.RelativeOrAbsolute);
            pieceImg.Source = bi;
            pieceImg.Height = 60;
            pieceImg.Width = 30;
        }
    }
}