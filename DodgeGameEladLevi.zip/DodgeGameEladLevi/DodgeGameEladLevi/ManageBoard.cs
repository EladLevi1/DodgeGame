﻿using System;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace DodgeGameEladLevi
{
    class ManageBoard
    {
        private Random r = new Random();
        private int cnvsW;
        private int cnvsH;
        private Canvas cnvs;
        private Enemy[] enemies;
        private Player player;
        private int level;
        private int enms = 0; // משתנה ברגע שהאוייבים מתנגשים אחד בשני
        private int ens = 0; // לא משתנה
        private TextBlock enemiesDestroyed = new TextBlock();
        private TextBlock levels = new TextBlock();
        private int counterEnemiesDestroyed = 0;
        private Image[] destroyedPic;
        private Button pause = new Button();
        private Button resume = new Button();
        private Button back = new Button();
        private Button nextLevel = new Button();
        public bool pauseClick = false;
        public bool backMenu = false;
        public bool next = false;

        public ManageBoard(int enemies, int level, Canvas cnvs)
        {
            this.cnvs = cnvs;
            cnvsW = (int)Window.Current.Bounds.Width;
            cnvsH = (int)Window.Current.Bounds.Height;
            this.enms = enemies;
            this.ens = enemies;
            this.level = level;
            this.enemies = new Enemy[enms];
            this.destroyedPic = new Image[enms];
            for (int i = 0; i < enemies; i++)
            {
                this.enemies[i] = new Enemy();
            }
            player = new Player();
            cnvs.Children.Clear();
            firstPos();
            showPieces();
            TextBlockEnemies();
            showLevel();
            pauseAndResume();
            backToMenu();
        }

        private void showLevel()
        {
            levels.Text = $"Level {level}";
            levels.FontSize = 40;
            levels.Foreground = new SolidColorBrush(Colors.White);
            Canvas.SetLeft(levels, cnvsW / 2 - 50);
            Canvas.SetTop(levels, 10);
            cnvs.Children.Add(levels);
        }

        private void showPieces()
        {
            showEnemy();
            showPlayer();
        }

        private void firstPos()
        {
            for (int i = 0; i < enms / 2; i++)
            {
                enemies[i].wp = r.Next(cnvsW);
                enemies[i].hp = r.Next((cnvsH / 2) / 2);
            }
            for (int i = enms / 2; i < enms; i++)
            {
                enemies[i].wp = r.Next(cnvsW);
                enemies[i].hp = r.Next(cnvsH / 2 + (cnvsH / 2 / 2), cnvsH);
            }

            player.wp = cnvsW / 2 - 30;
            player.hp = cnvsH / 2 - 30;
        }

        private void showEnemy()
        {
            for (int i = 0; i < enms; i++)
            {
                cnvs.Children.Add((Image)enemies[i].pieceImg);
                Canvas.SetLeft(enemies[i].pieceImg, enemies[i].wp);
                Canvas.SetTop(enemies[i].pieceImg, enemies[i].hp);
                cnvs.Children[cnvs.Children.IndexOf(enemies[i].pieceImg)].Visibility = Windows.UI.Xaml.Visibility.Visible;
            }
        }

        private void showPlayer()
        {
            cnvs.Children.Add((Image)player.pieceImg);
            Canvas.SetLeft(player.pieceImg, player.wp);
            Canvas.SetTop(player.pieceImg, player.hp);
            cnvs.Children[cnvs.Children.IndexOf(player.pieceImg)].Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void pauseAndResume()
        {
            pause.FontSize = 40;
            pause.Content = "Pause";
            Canvas.SetLeft(pause, cnvsW - 400);
            Canvas.SetTop(pause, 10);
            cnvs.Children.Add(pause);
            pause.Click += pause_Click;
            resume.FontSize = 40;
            resume.Content = "Resume";
            Canvas.SetLeft(resume, cnvsW - 400);
            Canvas.SetTop(resume, 10);
            cnvs.Children.Add(resume);
            resume.Visibility = Visibility.Collapsed;
            resume.Click += resume_Click;
        }
        private void pause_Click(object sender, RoutedEventArgs e)
        {
            pauseClick = true;
            pause.Visibility = Visibility.Collapsed;
            resume.Visibility = Visibility.Visible;
        }
        private void resume_Click(object sender, RoutedEventArgs e)
        {
            pauseClick = false;
            resume.Visibility = Visibility.Collapsed;
            pause.Visibility = Visibility.Visible;
        }

        private void backToMenu()
        {
            back.FontSize = 40;
            back.Content = "Menu";
            Canvas.SetLeft(back, cnvsW - 200);
            Canvas.SetTop(back, 10);
            cnvs.Children.Add(back);
            back.Click += back_Click;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            backMenu = true;
        }

        private bool loseGame()
        {
            bool isLose = false;
            for (int i = 0; i < enms; i++)
            {
                if (player.wp - enemies[i].wp >= -25 && player.wp - enemies[i].wp <= 0 && player.hp - enemies[i].hp <= 45 && player.hp - enemies[i].hp >= 0 || // פינה שמאל למטה
                    player.wp - enemies[i].wp <= 50 && player.wp - enemies[i].wp >= 0 && player.hp - enemies[i].hp <= 45 && player.hp - enemies[i].hp >= 0 || // פינה ימין למטה
                    player.wp - enemies[i].wp >= -25 && player.wp - enemies[i].wp <= 0 && player.hp - enemies[i].hp >= -45 && player.hp - enemies[i].hp <= 0 || // פינה שמאל למעלה
                    player.wp - enemies[i].wp <= 50 && player.wp - enemies[i].wp >= 0 && player.hp - enemies[i].hp >= -45 && player.hp - enemies[i].hp <= 0) // פינה ימין למעלה
                {
                    isLose = true;
                }
            }
            return isLose;
        }

        private bool winGame()
        {
            bool isWin = false;
            if (counterEnemiesDestroyed >= ens - 1)
            {
                isWin = true;
            }
            return isWin;
        }

        public bool endGame()
        {
            if (winGame() == true || loseGame() == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void winOrLose()
        {
            if (winGame() == true)
            {
                TextBlock roundCompleted = new TextBlock();
                roundCompleted.Text = $"Level {level} Completed!";
                roundCompleted.FontSize = 60;
                roundCompleted.Foreground = new SolidColorBrush(Colors.White);
                Canvas.SetLeft(roundCompleted, cnvsW / 2 - 250);
                Canvas.SetTop(roundCompleted, cnvsH / 2 - 100);
                cnvs.Children.Add(roundCompleted);

                nextLevel.Content = "Next Level";
                nextLevel.FontSize = 20;
                Canvas.SetLeft(nextLevel, cnvsW / 2 - 100);
                Canvas.SetTop(nextLevel, cnvsH / 2);
                cnvs.Children.Add(nextLevel);
                nextLevel.Click += nextLevel_Click;

                back.FontSize = 20;
                Canvas.SetLeft(back, cnvsW / 2 + 30);
                Canvas.SetTop(back, cnvsH / 2);
                cnvs.Children.Add(back);
            }
            if (loseGame() == true)
            {
                TextBlock gameLost = new TextBlock();
                gameLost.Text = $"You Lost The Game At Level {level}!";
                gameLost.FontSize = 60;
                gameLost.Foreground = new SolidColorBrush(Colors.White);
                Canvas.SetLeft(gameLost, cnvsW / 2 - 370);
                Canvas.SetTop(gameLost, cnvsH / 2 - 100);
                cnvs.Children.Add(gameLost);
                back.FontSize = 20;
                Canvas.SetLeft(back, cnvsW / 2 - 30);
                Canvas.SetTop(back, cnvsH / 2);
                cnvs.Children.Add(back);
            }
        }

        private void nextLevel_Click(object sender, RoutedEventArgs e)
        {
            next = true;
        }

        private void collision()
        {
            for (int i = 0; i < enms; i++)
            {
                for (int j = 0; j < enms; j++)
                {
                    if (i != j)
                    {
                        if (enemies[i].wp - enemies[j].wp >= -50 && enemies[i].wp - enemies[j].wp <= 0 && enemies[i].hp - enemies[j].hp <= 50 && enemies[i].hp - enemies[j].hp >= 0 ||
                            enemies[i].wp - enemies[j].wp <= 50 && enemies[i].wp - enemies[j].wp >= 0 && enemies[i].hp - enemies[j].hp <= 50 && enemies[i].hp - enemies[j].hp >= 0 ||
                            enemies[i].wp - enemies[j].wp >= -50 && enemies[i].wp - enemies[j].wp <= 0 && enemies[i].hp - enemies[j].hp >= -50 && enemies[i].hp - enemies[j].hp <= 0 ||
                            enemies[i].wp - enemies[j].wp <= 50 && enemies[i].wp - enemies[j].wp >= 0 && enemies[i].hp - enemies[j].hp >= -50 && enemies[i].hp - enemies[j].hp <= 0)
                        {
                            counterEnemiesDestroyed++;
                            BitmapImage bi = new BitmapImage();
                            bi.UriSource = new Uri("ms-appx:///Assets/ghost.jpg", UriKind.RelativeOrAbsolute);
                            destroyedPic[counterEnemiesDestroyed - 1] = new Image();
                            destroyedPic[counterEnemiesDestroyed - 1].Source = bi;
                            destroyedPic[counterEnemiesDestroyed - 1].Height = 60;
                            destroyedPic[counterEnemiesDestroyed - 1].Width = 60;
                            Canvas.SetLeft(destroyedPic[counterEnemiesDestroyed - 1], enemies[i].wp);
                            Canvas.SetTop(destroyedPic[counterEnemiesDestroyed - 1], enemies[i].hp);
                            cnvs.Children.Remove(enemies[i].pieceImg);
                            cnvs.Children.Add(destroyedPic[counterEnemiesDestroyed - 1]);
                            if (i < enms)
                            {
                                for (int x = i; x < enms; x++)
                                {
                                    enemies[i] = enemies[x];
                                }
                            }
                            enms--;
                            enemiesDestroyed.Text = "Enemies Eliminated: " + counterEnemiesDestroyed;
                        }
                    }
                }
            }
        }

        public void movingEnemies()
        {
            for (int i = 0; i < enms; i++)
            {
                if (enemies[i].wp < player.wp)
                {
                    enemies[i].wp += 10;
                    cnvs.Children.Remove(enemies[i].pieceImg);
                }
                if (enemies[i].wp > player.wp)
                {
                    enemies[i].wp -= 10;
                    cnvs.Children.Remove(enemies[i].pieceImg);
                }
                if (enemies[i].hp < player.hp)
                {
                    enemies[i].hp += 10;
                    cnvs.Children.Remove(enemies[i].pieceImg);
                }
                if (enemies[i].hp > player.hp)
                {
                    enemies[i].hp -= 10;
                    cnvs.Children.Remove(enemies[i].pieceImg);
                }
            }
            showEnemy();
            collision();
            loseGame();
            winGame();
        }

        public void clearBoard()
        {
            cnvs.Children.Remove(player.pieceImg);
            for (int i = 0; i < enms; i++)
            {
                cnvs.Children.Remove(enemies[i].pieceImg);
            }
            for (int i = 0; i < destroyedPic.Length; i++)
            {
                cnvs.Children.Remove(destroyedPic[i]);
            }
            enemiesDestroyed.Text = "";
            levels.Text = "";
            player.pieceImg.Source = null;
            cnvs.Children.Remove(resume);
            cnvs.Children.Remove(pause);
            cnvs.Children.Remove(back);
            winOrLose();
        }

        private void TextBlockEnemies()
        {
            TextBlock txt = new TextBlock();
            txt.Text = "Enemies Eliminated: ";
            txt.FontSize = 40;
            txt.Foreground = new SolidColorBrush(Colors.White);
            Canvas.SetLeft(txt, 10);
            Canvas.SetTop(txt, 10);
            cnvs.Children.Add(txt);
            enemiesDestroyed = txt;
        }

        public void MoveLeft()
        {
            if (player.wp >= 11)
            {
                player.wp -= 15;
                cnvs.Children.Remove(player.pieceImg);
                showPlayer();
            }
        }
        public void MoveTop()
        {
            if (player.hp >= 11)
            {
                player.hp -= 15;
                cnvs.Children.Remove(player.pieceImg);
                showPlayer();
            }
        }
        public void MoveRight()
        {
            if (player.wp <= cnvsW - 31)
            {
                player.wp += 15;
                cnvs.Children.Remove(player.pieceImg);
                showPlayer();
            }
        }
        public void MoveDown()
        {
            if (player.hp <= cnvsH - 61)
            {
                player.hp += 15;
                cnvs.Children.Remove(player.pieceImg);
                showPlayer();
            }
        }
    }
}