﻿using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace DodgeGameEladLevi
{
    class Piece
    {
        public int wp;
        public int hp;
        public Image pieceImg;
        public virtual void img() { }
    }
}