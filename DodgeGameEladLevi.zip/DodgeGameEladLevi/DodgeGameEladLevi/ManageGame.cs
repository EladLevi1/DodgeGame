﻿using System;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace DodgeGameEladLevi
{
    class ManageGame
    {
        private int enemy = 5;
        private int speed;
        private int level = 1;
        private Canvas cnvs;
        private ManageBoard mnb;
        private DispatcherTimer dispatcherTimer;
        private DispatcherTimer tempTimer;


        public ManageGame(int speed, Canvas cnvs)
        {
            this.speed = speed;
            this.cnvs = cnvs;
            Window.Current.CoreWindow.KeyDown += CoreWindow_KeyDown;
            startGame();
        }

        private void startGame()
        {
            mnb = new ManageBoard(enemy, level, cnvs);
            Timer();
        }

        private void Timer()
        {
            dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, speed * 100);
            dispatcherTimer.Tick += DispatcherTimer_Tick;
            dispatcherTimer.Start();
        }

        public bool BackToMenu()
        {
            if (mnb.backMenu == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void pauseAndResume()
        {
            if (mnb.pauseClick == false)
            {
                mnb.movingEnemies();
            }
        }

        private void DispatcherTimer_Tick(object sender, object e)
        {
            pauseAndResume();
            if (mnb.endGame() == true)
            {
                mnb.clearBoard();
                dispatcherTimer.Stop();
                tempTimer = new DispatcherTimer();
                tempTimer.Interval = new TimeSpan(0, 0, 0, 0, 1);
                tempTimer.Tick += tempTimer_Tick;
                tempTimer.Start();
            }
        }

        private void tempTimer_Tick(object sender, object e)
        {
            if (mnb.next == true)
            {
                tempTimer.Stop();
                enemy += 5;
                level++;
                startGame();
            }
        }

        private void CoreWindow_KeyDown(CoreWindow sender, KeyEventArgs args)
        {
            if (mnb.pauseClick == false)
            {
                switch (args.VirtualKey)
                {
                    case VirtualKey.Left:
                        mnb.MoveLeft();
                        return;
                    case VirtualKey.A:
                        mnb.MoveLeft();
                        return;
                    case VirtualKey.Right:
                        mnb.MoveRight();
                        return;
                    case VirtualKey.D:
                        mnb.MoveRight();
                        return;
                    case VirtualKey.Up:
                        mnb.MoveTop();
                        return;
                    case VirtualKey.W:
                        mnb.MoveTop();
                        return;
                    case VirtualKey.Down:
                        mnb.MoveDown();
                        return;
                    case VirtualKey.S:
                        mnb.MoveDown();
                        return;
                }
            }
        }
    }
}